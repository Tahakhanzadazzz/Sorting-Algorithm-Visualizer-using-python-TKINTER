# Python program for implementation of Insertion Sort
import matplotlib.pyplot as plt
import numpy as np


# Function to do insertion sort
def insertionSort(arr):
    x = np.arange(0, 15, 1)
    # Traverse through 1 to len(arr)
    for i in range(1, len(arr)):
        plt.bar(x, lst)
        plt.pause(1)
        plt.clf()

        key = arr[i]

        # Move elements of arr[0..i-1], that are
        # greater than key, to one position ahead
        # of their current position
        j = i - 1
        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
amount = 15
lst = np.random.randint(0, 100, amount)
def main():
    x = np.arange(0, amount, 1)
    insertionSort(lst)
    for i in range(len(lst)):
        print("% d" % lst[i])
    plt.bar(x, lst)
    plt.pause(1)
    plt.show()
main()

# This code is contributed by Mohit Kumra