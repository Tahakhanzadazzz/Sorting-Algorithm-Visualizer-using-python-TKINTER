# from tkinter import ttk
# from tkinter import*
# import time

# root = Tk()

# def load():
#     current_value = Loading_bar.cget('value')
#     if current_value < 100:
#         root.after(10, load)
#     Loading_bar.config(value=current_value+1)

# Loading_bar = ttk.Progressbar(root, orient = HORIZONTAL,
#                             length = 500, mode = 'determinate')
# Loading_bar.pack()

# load()

# root.mainloop()
from tkinter import *

# Create the root window
root = Tk()

# Create a label
label = Label(root, text="Hello, world!")
label.pack()

# Schedule the label to be removed after 1000 milliseconds (1 second)
root.after(1000, lambda: label.pack_forget())

# Run the Tkinter event loop
root.mainloop()