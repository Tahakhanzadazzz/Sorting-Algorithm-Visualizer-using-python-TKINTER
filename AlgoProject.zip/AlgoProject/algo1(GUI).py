from tkinter import *
from tkinter import ttk
import tkinter as tk
import time
import random
import numpy as np
from tkinter import messagebox

def dest():
    root.after(3000, root.destroy)
def smallfile():
    msg_box = tk.messagebox.showinfo('Small Size File', 'Ten Random Numbers will be Generated in this file'
                                        )

def mediumfile():
    msg_box = tk.messagebox.showinfo('Medium Size File', 'Thousands Random Numbers will be Generated in this file'
                                        )

def largefile():
    msg_box = tk.messagebox.showinfo('Large File', 'Million Random Numbers will be Generated in this file',
                                        icon='warning')

def run():
    current_value = Loading_bar.cget('value')
    # Loading_bar.place(x=220, y=480)
    if current_value < 100:
        root.after(10, run)
        Loading_bar.config(value=current_value + 1)
    Loading_bar.place(x=170, y=90)
    dest()


# This function will draw randomly generated list data[] on the canvas as vertical bars
def set_speed():
    if speed_menu.get() == 'Slow':
        return 0.3
    elif speed_menu.get() == 'Medium':
        return 0.1
    else:
        return 0.001

def complexity():
    if algo_menu.get() == 'Bubble Sort' and speed_menu.get()=='Small':
        from bubble_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580)
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Bubble Sort Worstcase=O(n²) AverageCase=O(n²) BestCase=O(n) ",bg="grey").place(x=495,y=620)
        

    elif algo_menu.get() == 'Bubble Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from bubble_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="BubbleSort Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580)
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Bubble Sort Worstcase=O(n²) AverageCase=O(n²) BestCase=O(n) ",bg="grey").place(x=495,y=620)
        # root.after(1000, lambda: label.pack_forget())
        

    elif algo_menu.get() == 'Bubble Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from bubble_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580)
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Bubble Sort Worstcase=O(n²) AverageCase=O(n²) BestCase=O(n) ",bg="grey").place(x=495,y=620)
        # root.after(1000,lambda:label.pack_forget())
        

    elif algo_menu.get() == 'Bucket Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from bucket_small import timetaken
        Timecomplexity= timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580)
        label=Label(root,text="Space Complexity= O(n+k)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Bucket Sort Worstcase=O(n²) AverageCase=O(n+k) BestCase=O(n+k) ",bg="grey").place(x=495,y=620)
        
        

    elif algo_menu.get() == 'Bucket Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from bucket_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580)
        label=Label(root,text="Space Complexity= O(n+k)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Bucket Sort Worstcase=O(n²) AverageCase=O(n+k) BestCase=O(n+k) ",bg="grey").place(x=495,y=620)
         


    elif algo_menu.get() == 'Bucket Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from bucket_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580)
        label=Label(root,text="Space Complexity= O(n+k)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Bucket Sort Worstcase=O(n²) AverageCase=O(n+k) BestCase=O(n+k) ",bg="grey").place(x=495,y=620)
         

    elif algo_menu.get() == 'Insertion Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from insertion_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580)   
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Insertion Sort Worstcase=O(n²) AverageCase=O(n²) BestCase=O(n) ",bg="grey").place(x=495,y=620)
        
    elif algo_menu.get() == 'Insertion Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from insertion_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Insertion Sort Worstcase=O(n²) AverageCase=O(n²) BestCase=O(n) ",bg="grey").place(x=495,y=620)
        
    elif algo_menu.get() == 'Insertion Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from insertion_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Insertion Sort Worstcase=O(n²) AverageCase=O(n²) BestCase=O(n) ",bg="grey").place(x=495,y=620)
        # root.after(1000,lambda:label.pack_forget())

    elif algo_menu.get() == 'Merge Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from merge_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Merge Sort Worstcase=O(nlogn) AverageCase=O(nlogn) BestCase=O(nlogn) ",bg="grey").place(x=495,y=620)
       
    elif algo_menu.get() == 'Merge Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from merge_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Merge Sort Worstcase=O(nlogn) AverageCase=O(nlogn) BestCase=O(nlogn) ",bg="grey").place(x=495,y=620)
       
    elif algo_menu.get() == 'Merge Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from merge_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Merge Sort Worstcase=O(nlogn) AverageCase=O(nlogn) BestCase=O(nlogn) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Quick Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from quicksort_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(logn)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Quick Sort Worstcase=O(n²) AverageCase=O(nlogn) BestCase=O(nlogn) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Quick Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from quicksort_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(logn)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Quick Sort Worstcase=O(n²) AverageCase=O(nlogn) BestCase=O(nlogn) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Quick Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from quicksort_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(logn)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Quick Sort Worstcase=O(n²) AverageCase=O(nlogn) BestCase=O(nlogn) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Heap Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from heap_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Heap Sort Worstcase=O(nlogn) AverageCase=O(nlogn) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Heap Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from heap_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Heap Sort Worstcase=O(nlogn) AverageCase=O(nlogn) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Heap Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from heap_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(1)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Heap Sort Worstcase=O(nlogn) AverageCase=O(nlogn) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Radix Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from radix_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n+2^d)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Radix Sort Worstcase=O(n*k/d) AverageCase=O(nk) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Radix Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from radix_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n+2^d)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Radix Sort Worstcase=O(n*k/d) AverageCase=O(nk) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Radix Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from radix_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n+2^d)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Radix Sort Worstcase=O(n*k/d) AverageCase=O(nk) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Counting Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from Counting_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n+r)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Count Sort Worstcase=O(n) AverageCase=O(n) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Counting Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from Counting_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n+r)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Count Sort Worstcase=O(n) AverageCase=O(n) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Counting Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from Counting_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n+r)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Count Sort Worstcase=O(n) AverageCase=O(n) BestCase=O(n) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Improved Quick Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from updatedquick_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Improved Quick Sort O(nk + n log(n/k)) ",bg="grey").place(x=495,y=620)
    
    elif algo_menu.get() == 'Improved Quick Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from updatedquick_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Improved Quick Sort O(nk + n log(n/k)) ",bg="grey").place(x=495,y=620)

    elif algo_menu.get() == 'Improved Quick Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from updatedquick_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Improved Quick Sort O(nk + n log(n/k)) ",bg="grey").place(x=495,y=620)

    elif algo_menu.get() == 'Book 8' and speed_menu.get()=='Large':
        # time.sleep(8)
        from book8_large import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Book 8.2.4 O(nCk) ",bg="grey").place(x=495,y=620)

    elif algo_menu.get() == 'Book 8' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from book8_medium import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Book 8.2.4 O(nCk) ",bg="grey").place(x=495,y=620)

    elif algo_menu.get() == 'Book 8' and speed_menu.get()=='Small':
        # time.sleep(8)
        from book8_small import timetaken
        Timecomplexity=timetaken()
        label=Label(root,text="Timecomplexity= {}".format(Timecomplexity),bg="grey").place(x=495,y=580) 
        label=Label(root,text="Space Complexity= O(n)" ,bg="grey").place(x=744,y=580)
        label=Label(root,text="Book 8.2.4 O(nCk) ",bg="grey").place(x=495,y=620)
    




def sort():

    if algo_menu.get() == 'Bubble Sort' and speed_menu.get()=='Small':
          from bubble_small import main
          main()

    elif algo_menu.get() == 'Bubble Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from bubble_medium import main
        main()

    elif algo_menu.get() == 'Bubble Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from bubble_large import main
        main()  

    elif algo_menu.get() == 'Bucket Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from bucket_small import main
        main() 
    elif algo_menu.get() == 'Bucket Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from bucket_medium import main
        main()          
    elif algo_menu.get() == 'Bucket Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from bucket_large import main
        main()          
    elif algo_menu.get() == 'Insertion Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from insertion_small import main
        main()   

    elif algo_menu.get() == 'Insertion Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from insertion_medium import main
        main() 

    elif algo_menu.get() == 'Insertion Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from insertion_large import main
        main() 
    elif algo_menu.get() == 'Merge Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from merge_large import main
        main()  
    elif algo_menu.get() == 'Merge Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from merge_medium import main
        main()
    elif algo_menu.get() == 'Merge Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from merge_small import main
        main()  

    elif algo_menu.get() == 'Quick Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from quicksort_small import main
        main()                        
    elif algo_menu.get() == 'Quick Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from quicksort_medium import main
        main()                        
    elif algo_menu.get() == 'Quick Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from quicksort_large import main
        main()                        
    elif algo_menu.get() == 'Heap Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from heap_large import main
        main()      

    elif algo_menu.get() == 'Heap Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from heap_medium import main
        main()        

    elif algo_menu.get() == 'Heap Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from heap_small import main
        main()  

    elif algo_menu.get() == 'Radix Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from radix_small import main
        main()    

    elif algo_menu.get() == 'Radix Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from radix_medium import main
        main()                        
    elif algo_menu.get() == 'Radix Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from radix_large import main
        main()        

    elif algo_menu.get() == 'Counting Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from Counting_large import main
        main()   

    elif algo_menu.get() == 'Counting Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from Counting_medium import main
        main()     

    elif algo_menu.get() == 'Counting Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from Counting_small import main
        main()                        
    elif algo_menu.get() == 'Improved Quick Sort' and speed_menu.get()=='Small':
        # time.sleep(8)
        from updatedquick_small import main
        main()       

    elif algo_menu.get() == 'Improved Quick Sort' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from updatedquick_medium import main
        main()   

    elif algo_menu.get() == 'Improved Quick Sort' and speed_menu.get()=='Large':
        # time.sleep(8)
        from updatedquick_large import main
        main()         

    elif algo_menu.get() == 'Book 8' and speed_menu.get()=='Small':
        # time.sleep(8)
        from book8_small import main
        main()       

    elif algo_menu.get() == 'Book 8' and speed_menu.get()=='Medium':
        # time.sleep(8)
        from book8_medium import main
        main()    

    elif algo_menu.get() == 'Book 8' and speed_menu.get()=='Large':
        # time.sleep(8)
        from book8_large import main
        main()                        
    
    # elif algo_menu.get() == 'Insertion Sort':
    #     # time.sleep(8)
    #     from Insertion_sort import main
    #     main()


def exit():
    # import time
    # time.sleep(2)
    msg_box = tk.messagebox.askquestion('Exit Application', 'Are you sure you want to exit the application?',
                                        icon='warning')
    if msg_box == 'yes':
        run()
        # import time
        # time.sleep(1)
        # root.destroy()
    else:
        tk.messagebox.showinfo(
            'Return', 'You will now return to the application screen')


def on_enter(e):
    b1['background'] = "green"


def on_leave(e):
    b1['background'] = 'grey'


def on_enter2(e):
    b2['background'] = "red"


def on_leave2(e):
    b2['background'] = 'grey'

def on_enter3(e):
    b3['background'] = "green"


def on_leave3(e):
    b3['background'] = 'grey'


def on_enter4(e):
    b4['background'] = "green"


def on_leave4(e):
    b4['background'] = 'grey'

def on_enter5(e):
    b5['background'] = "red"


def on_leave5(e):
    b5['background'] = 'grey'

def on_enter6(e):
    b6['background'] = "Yellow"


def on_leave6(e):
    b6['background'] = 'grey'   

root = Tk()
root.wm_iconbitmap(r'C:\Users\E9ad\Desktop\AlgoProject\icon.ico')
root.geometry("1200x900")
root.title("Sorting Visualizer")


scrollbar = Scrollbar(root)
scrollbar.pack(side=RIGHT, fill=Y)
list = Listbox(root, yscrollcommand=scrollbar.set)
f1 = Frame(root, borderwidth=6, relief=SUNKEN, bg='#082A46')
f1.pack(pady=3, fill="y", padx=12)
l = Label(f1, text="Welcome to Sorting Algorithm Visualizer",
          font="lucida 33 bold", background="grey", relief=GROOVE, bd=5).pack()

selected_algo = StringVar()
root.config(bg='#082A46')

f2 = Frame(root, borderwidth=6, relief=SUNKEN, bg='#082A46', pady=20)
# f1.place(x=2,y=10)
f2.pack(pady=3, fill="y", padx=12)
l2 = Label(root, text="Select Algorithm", font="lucida 20 bold italic",
           background="grey", relief=GROOVE, bd=5).place(x=495,y=150)

algorithm_name = StringVar()
# algo_list is to select which alforithm we want to use to sort
algo_list = ['Bubble Sort', 'Merge Sort', 'Insertion Sort','Bucket Sort','Heap Sort','Quick Sort', 'Radix Sort', 'Counting Sort','Improved Quick Sort','Book 8']
speed_name = StringVar()
# speed_list is for selecting sorting speed
speed_list = ['Large', 'Medium', 'Small']
progressbar = Frame(root).place(x=220, y=690)
# blank = Frame(progressbar).place(x=0, y=0)
# def load():
Loading_bar = ttk.Progressbar(progressbar, orient=HORIZONTAL,
                              length=800, mode='determinate')


UI_frame = Frame(root, width=900, height=10, bg='grey')
UI_frame.place(x=520, y=210)

# dropdown to select sorting algorithm
l1 = Label(UI_frame, text="Algorithm: ", font="lucida 12 bold italic",bg="grey")
l1.pack(padx=10, pady=5)
algo_menu = ttk.Combobox(
    UI_frame, textvariable=algorithm_name, values=algo_list)
algo_menu.pack(padx=5, pady=5)
algo_menu.current(0)


l3 = Label(root, text="Select File Size", font="lucida 20 bold italic",
           background="grey", relief=GROOVE, bd=5).place(x=495, y=320)


UI_frame2 = Frame(root, width=300, height=150, bg='grey')
UI_frame2.place(x=520,y=380)
#
#
# dropdown to select sorting speed
l2 = Label(UI_frame2, text="File Size: ", font="lucida 12 bold italic",bg="grey")
l2.pack(padx=10, pady=5)
speed_menu = ttk.Combobox(UI_frame2, textvariable=speed_name, values=speed_list)
speed_menu.pack(padx=5, pady=5)
speed_menu.current(2)


# l3 = Label(root, text="Select File Size", font="lucida 20 bold italic",
#            background="grey", relief=GROOVE, bd=5).place(x=480, y=340)
# sort button
b1 = Button(root, text="Sort", command=sort, bg="grey",
            font="lucida 14 bold",height=1,width=5)
b1.bind("<Enter>", on_enter)
b1.bind("<Leave>", on_leave)
b1.place(x=495, y=532)

b2 = Button(root, text="Exit", command=exit, bg="grey", font="lucida 14 bold",height=1,width=5)
b2.bind("<Enter>", on_enter2)
b2.bind("<Leave>", on_leave2)
b2.place(x=570, y=532)


b3 = Button(root, text="Small", command=smallfile, bg="grey", font="lucida 14 bold",height=1,width=5)
b3.bind("<Enter>", on_enter3)
b3.bind("<Leave>", on_leave3)
b3.place(x=495, y=480)


b4 = Button(root, text="Medium", command=mediumfile, bg="grey", font="lucida 14 bold",height=1,width=6)
b4.bind("<Enter>", on_enter4)
b4.bind("<Leave>", on_leave4)
b4.place(x=570, y=480)

b5= Button(root, text="Large", command=largefile, bg="grey", font="lucida 14 bold",height=1,width=5)
b5.bind("<Enter>", on_enter5)
b5.bind("<Leave>", on_leave5)
b5.place(x=655, y=480)

b6= Button(root, text="RunTime", command=complexity, bg="grey", font="lucida 14 bold",height=1,width=6)
b6.bind("<Enter>", on_enter6)
b6.bind("<Leave>", on_leave6)
b6.place(x=645, y=532)

# root.after(1000,lambda:label.pack_forget())
# f3 = Frame(root, borderwidth=6, relief=SUNKEN, bg='#082A46', pady=20)
# # f1.place(x=2,y=10)
# f3.place(x=500,y=300)
# l3 = Label(root, text="Select File Size", font="lucida 20 bold italic",
#            background="grey", relief=GROOVE, bd=5).place(x=480, y=360)


# b3 = Button(root, text="Small", command=sort, bg="grey",
#             font="lucida 14 bold")
# b3.bind("<Enter>", on_enter)
# b3.bind("<Leave>", on_leave)
# b3.place(x=670, y=382)



# frame = Frame(root, width=300, height=40)
# frame.place(x=369, y=600)
# frame.place(anchor='s', relx=0.5, rely=0.5)


# Execute Tkinter


# IMAGE_PATH = 'image1.png'
# WIDTH, HEIGTH = 200, 200
#
# # root = tk.Tk()
# root.geometry('{}x{}'.format(WIDTH, HEIGTH))
#
# canvas = tk.Canvas(root, width=WIDTH, height=HEIGTH)
# canvas.pack()
#
# img = ImageTk.PhotoImage(Image.open(IMAGE_PATH).resize((WIDTH, HEIGTH), Image.ANTIALIAS))
# canvas.background = img  # Keep a reference in case this code is put in a function.
# bg = canvas.create_image(0, 0, anchor=tk.NW, image=img)

root.mainloop()