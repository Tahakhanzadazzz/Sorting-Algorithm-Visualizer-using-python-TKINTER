import matplotlib.pyplot as plt 
import numpy as np
import numpy
import time

def insertionSort(b):
    for i in range(1, len(b)):
        up = b[i]
        j = i - 1
        while j >= 0 and b[j] > up: 
            b[j + 1] = b[j]
            j -= 1
        b[j + 1] = up     
    return b     

def bucketSort(x):
    arr = []
    slot_num = 10 # 10 means 10 slots, each
                  # slot's size is 0.1
    for i in range(slot_num):
        arr.append([])
          
    # Put array elements in different buckets 
    for j in x:
        index_b = int(slot_num * j) 
        arr[index_b].append(j)
      
    # Sort individual buckets 
    for i in range(slot_num):
        arr[i] = insertionSort(arr[i])
          
    # concatenate the result
    k = 0
    for i in range(slot_num):
        for j in range(len(arr[i])):
            x[k] = arr[i][j]
            k += 1

def bucketSort_medium(lst):
    x= np.arange(0, 10, 1)
    arr = []
    slot_num = 10 # 10 means 10 slots, each
                  # slot's size is 0.1
    for i in range(slot_num):
        arr.append([])
          
    # Put array elements in different buckets 
    for j in lst:
        # set the default color for the bars
        color = 'b'

        # if sorting a value, set the color to red
        if j in lst[:i]:
            color = 'r'

        # plot the bars with the appropriate color
        plt.bar(x, lst, color=color)
        plt.xlabel("ArrayElements")
        plt.ylabel("Values")
        plt.title("Bucket Sort")
        plt.pause(0.1)
        plt.clf()
        index_b = int(slot_num * j) 
        arr[index_b].append(j)
    
    # Set the colors of the bars to a list of the same color
    color_list = ["blue"] * len(lst)
    # Sort individual buckets 
    for i in range(slot_num):
        plt.bar(x, lst, color=color_list)
        plt.xlabel("ArrayElements")
        plt.ylabel("Values")
        plt.title("Bucket Sort")
        plt.pause(0.2)
        plt.clf()
        
        # Update the colors of the values being sorted
        for j in range(len(arr[i])):
            color_list[j] = "red"
            
        arr[i] = insertionSort(arr[i])
          
    # concatenate the result
    k = 0
    for i in range(slot_num):
        for j in range(len(arr[i])):
            plt.bar(x, lst, color='grey')
            plt.pause(0.2)
            plt.clf()
            lst[k] = arr[i][j]
            k += 1
    plt.bar(x, lst)
    plt.pause(0.5)
  
# Driver Code 
def main():
    amount = 1000
    lst = numpy.random.uniform(0,1,amount)

    with open('medium.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(float(line))

    array=[]
    for i in range(10):
        array.append(new_list[i])

    bucketSort_medium(array)
    plt.show()

def timetaken():
    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(float(line))
    start_time = time.time()
    # now sorting the complete array
    bucketSort(new_list)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time
