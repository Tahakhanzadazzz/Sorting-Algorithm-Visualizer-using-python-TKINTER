import matplotlib.pyplot as plt 
import numpy as np
import numpy
import time

def counting_sort_large(arr, k):
    x= np.arange(0, 10, 1)
    # Initialize counting array with size k+1 to account for 0
    counting_arr = [0] * (k+1)
    # Count the frequency of each element in the array
    for i in range(len(arr)):
        counting_arr[arr[i]] += 1

    # Create the output array
    output = []

    # Place the elements back into the output array in the correct order
    # Create the output array
    output = []

    # Place the elements back into the output array in the correct order
    for i in range(k+1):
        for j in range(counting_arr[i]):
            output.append(i)
    return output


def counting_sort(arr, k):
    # Initialize counting array with size k+1 to account for 0
    counting_arr = [0] * (k+1)
    # Count the frequency of each element in the array
    for i in range(len(arr)):
        counting_arr[arr[i]] += 1

    # Create the output array
    output = []

    # Place the elements back into the output array in the correct order
    for i in range(k+1):
        for j in range(counting_arr[i]):
            output.append(i)

def query(arr, a, b):
    count = 0
    # Count the number of elements in the range a to b
    for i in range(len(arr)):
        if a <= arr[i] <= b:
            count += 1
    return count

def main():
    amount = 1000000
    lst = np.random.randint(0, 100, amount)
    x= np.arange(0, 10, 1)
    with open('large.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('large.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    array=[]
    for i in range(10):
        array.append(new_list[i])
    k=100
    arr=counting_sort_large(array, k)

    plt.bar(x,arr)
    plt.xlabel("ArrayElements")
    plt.ylabel("Values")
    plt.title("Book 8")
    plt.pause(0.2)
    plt.show()
    a = 1
    b = 4
    count = query(new_list, a, b)
    print("Number of elements in the range", a, "to", b, ":", count)

def timetaken():
    new_list = []
    with open('large.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    start_time = time.time()
    k=100
    # now sorting the complete array
    counting_sort(new_list, k)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time

