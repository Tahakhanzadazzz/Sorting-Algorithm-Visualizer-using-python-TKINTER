import matplotlib.pyplot as plt 
import numpy as np
import time


def partition(array, low, high):

	pivot = array[high]

	i = low - 1

	for j in range(low, high):
		if array[j] <= pivot:

			i = i + 1

			# Swapping element at i with element at j
			(array[i], array[j]) = (array[j], array[i])

	# Swap the pivot element with the greater element specified by i
	(array[i + 1], array[high]) = (array[high], array[i + 1])

	# Return the position from where partition is done
	return i + 1



def quickSort(array, low, high):
	if low < high:
		pi = partition(array, low, high)

		# Recursive call on the left of pivot
		quickSort(array, low, pi - 1)

		# Recursive call on the right of pivot
		quickSort(array, pi + 1, high)



def partition_large(array, low, high):
	# choose the rightmost element as pivot
	pivot = array[high]

	# pointer for greater element
	i = low - 1

	# traverse through all elements
	# compare each element with pivot
	for j in range(low, high):
		if array[j] <= pivot:

			i = i + 1

			# Swapping element at i with element at j
			(array[i], array[j]) = (array[j], array[i])

	# Swap the pivot element with the greater element specified by i
	(array[i + 1], array[high]) = (array[high], array[i + 1])

	# Return the position from where partition is done
	return i + 1

# function to perform quicksort


def quickSort_large(array, low, high):
    x= np.arange(0, 10, 1)
    if low < high:

        pi = partition_large(array, low, high)
        # color the comparing elements with a different color
        color = ["#0000FF" for i in range(len(array))]
        color[low] = "#FF0000"
        color[high] = "#FF0000"
        plt.bar(x, array, color=color)
        plt.xlabel("ArrayElements")
        plt.ylabel("Values")
        plt.title("Quick Sort")
        plt.pause(0.4)
        plt.clf()

        # Recursive call on the left of pivot
        quickSort_large(array, low, pi - 1)

        # Recursive call on the right of pivot
        quickSort_large(array, pi + 1, high)


def main():
    amount = 1000000
    lst = np.random.randint(0, 1000000, amount)
    x= np.arange(0, 10, 1)
    with open('large.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('large.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))

    array=[]
    for i in range(10):
        array.append(new_list[i])
    n = len(array)
    quickSort_large(array, 0, n - 1)
    plt.bar(x, array)
    plt.xlabel("ArrayElements")
    plt.ylabel("Values")
    plt.title("Quick Sort")
    plt.pause(0.001)
    plt.show()

def timetaken():
    new_list = []
    with open('large.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    
    n=len(new_list)
    start_time = time.time()
    # now sorting the complete array
    quickSort(new_list, 0 , n-1)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time
    

